
public class DataSetGen <T extends Measurable> {
	/**
	 * @author Chandra Krishnan
	 * This program is about converting DataSet into DataSetGen
	 * Now it can work with any type that implements the Measurable interface.
	 * The DataSet class is a class designed to store and process objects of a specific type 
	 * (example, BankAccount or BaseballPlayer). It has methods for: Adding elements, sum, maximum etc 
	 * related to "measurable" data
	 */
	
								//	Keeping old code (DataSet) to compare
								// 	private double sum;
								//	private Measurable maximum;
								//	private int count;
	
	// T is a generic type parameter.
	// T extends Measurable essentially means that T can only be a class that implements the Measurable interface.
	// NOW any object added to DataSetGen has a getMeasure() method.

	private double sum; // Keeps track of the total sum of getMeasure() values.
	private T maximum;	// Keeps track of the total sum of getMeasure() values
	private int count;	// counter
								//	 public DataSet()
								//	   {
								//	      sum = 0;
								//	      count = 0;
								//	      maximum = null;
								//	   }
	
	// constructing and initializing empty data set
	 public DataSetGen()
	   {
	      sum = 0; // set sum to zero
	      count = 0; // set counter to zero
	      maximum = null; // no elements added yet. so sets maximum to null or zero
	   }
								//	 public void add(Measurable x)
								//	   {
								//	      sum = sum + x.getMeasure();
								//	      if (count == 0 || maximum.getMeasure() < x.getMeasure())
								//	         maximum = x;
								//	      count++;
								//	   }
	 /**
	  * Adds a data value to the data set.
	  * @param x a data value
	  */
	 
	 public void add(T x) // adding object to dataset
	   {
	      sum = sum + x.getMeasure(); // updating sum by adding the getMeasure() value to object
	      if (count == 0 || maximum.getMeasure() < x.getMeasure())
	         maximum = x;
	      	// If this is the first object, it becomes the maximum.
	 	 	// Otherwise, it checks if the new object's getMeasure() is greater than the current maximum.
	      count++; // counter addition post-addition
	   }
								//	 public double getAverage()
								//	   {
								//	      if (count == 0) return 0;
								//	      else return sum / count;
								//	   }
	 /**
	  * 
	  * @return
	  */
	 public double getAverage()
	   {
	      if (count == 0) return 0;
	      else return sum / count;
	      // Returns 0 if there are no elements (to avoid division by zero).
	      // Otherwise, computes the average: sum / number of elements.
	   }
								//	 public Measurable getMaximum()
								//	   {
								//	      return maximum;
								//	   }
	 /**
     Gets the largest of the added data.
     @return the maximum or 0 if no data has been added
     Returns the object with the highest getMeasure() value.
	 If no elements were added, it returns null.
	  */
	  public T getMaximum()
	  {
	     return maximum;
	  }

}
